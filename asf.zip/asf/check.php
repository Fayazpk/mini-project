
<?php
include('connection.php');
$flag=0;
if(isset($_POST['save']))
{
    $email=$_POST['pmail'];
    $password=$_POST['ppass'];
}
$res=mysqli_query($con,"SELECT * FROM registration where Email_id='$email' and password='$password' ");
while($row=mysqli_fetch_array($res))
{
$flag=1;
}
if($flag==1)
{
    if($email=='admin@gmail.com' && $password=='admin'){
        header('location:adminhome.html');
    }
    else{
    header("location:home.php");
    }
}
else{
    ?>
    <script>
        alert("username/password does not match");window.location='login.php';
    </script>
    <?php
    // header("location:login.php");
}

?>
