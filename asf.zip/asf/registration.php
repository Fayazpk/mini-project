<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V1</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>

<script>  
function matchPassword(event) {   
  if (document.getElementById('pas2').value ==
   document.getElementById('pas1').value) {     
   document.getElementById('message').style.color = 'green';
   document.getElementById('message').innerHTML = 'matching';
  }  
  else{
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'Password not matching';
    event.preventDefault()
  }
}  
</script>


<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="images/peep.jpg" alt="IMG">
				</div>

				<form onsubmit="matchPassword(event)" class="login100-form validate-form" action='insert.php' method="post">
					<span class="login100-form-title">
						Registration
					</span>
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="pname" placeholder="First Name">
						
					
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="sname" placeholder="Last Name">
						
					
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="pnumber" placeholder="Phone Number">
						
					
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="pmail" placeholder="Email">
						
					
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="date" name="birthday" placeholder="Date Of Birth">
						
					
					</div>
					
					
					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="ppass" id="pas1" placeholder="Password">	
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="cpass" id="pas2" placeholder="Confirm Password">	
					</div>
					<span id="message">

</span>					<div class="wrap-input100 validate-input">
						&nbsp;&nbsp;&nbsp;<label style="font-family: Poppins-Regular;font-size: 17px;" for="female">FEMALE</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="female">&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;<label style="font-family: Poppins-Regular;font-size: 17px;" for="male">MALE</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="male">
					</div>
					<div data-validate = "Valid email is required: ex@abc.xyz">
						<input style="margin-left: 10px;" id="image" type="file" name="pphoto" placeholder="Photo" required="" capture>
					</div>
					<div class="container-login100-form-btn">
					<input type="submit" style="background-color: #62529c;border: none;color:white;padding: 15px 110px;text-decoration: none;margin: 4px 2px;cursor: pointer;border-radius: 25px;" value="REGISTER"  name="SIGNUP">
					</div>

	




					<div class="text-center p-t-136">
						<a class="txt2" href="login.php">
							Already have an Account
							<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>